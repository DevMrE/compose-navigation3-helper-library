package com.devmre.compose.navigation3.helper

import androidx.compose.runtime.Composable
import androidx.navigation3.runtime.NavKey
import org.koin.compose.koinInject
import org.koin.core.qualifier.named

inline fun <reified T : NavKey> navigatorQualifier() =
    named("navigator_${T::class.qualifiedName}")

@Composable
inline fun <reified T : NavKey> koinNavigation(): Navigator<T> {
    return koinInject<Navigator<T>>(qualifier = navigatorQualifier<T>())
}